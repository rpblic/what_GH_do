import numpy as np

arr = np.random.random(10)
arr.sort()

arr # 오름차순 정렬

arr[::-1].sort()

arr # 내림차순 정렬