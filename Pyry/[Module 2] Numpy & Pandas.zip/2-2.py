arr = np.arange(9)

arr = arr.reshape(3,3)

print(arr)