import csv
import random
import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import scale
import matplotlib.pyplot as plt
from random import shuffle, seed
import os
os.chdir('C:\\Studying\\myvenv\\GrowthHackers\\GH_내부프로젝트(pca,svm)\\DoSVM')

def opener():
    with open('..\\voice.csv', 'r') as f:
        #tuple of 3169 data
        #0: male, 1: female
        lines = f.readlines()
        y_at1, X_at1 = [], []
        y_at0, X_at0 = [], []
        for i, line in enumerate(lines):
            if i != 0:
                line = line[:-1]
                splited = line.split(',')
                if splited[0]== '1':
                    y_at1.append([int(splited[0])])
                    X_at1.append([float(value) for value in splited[1:]])
                else:
                    y_at0.append([int(splited[0])])
                    X_at0.append([float(value) for value in splited[1:]])
        length0= len(y_at0)
        length1= len(y_at1)
    random.Random(0).shuffle(X_at1)
    random.Random(0).shuffle(X_at0)
    X_train = np.array(X_at1[int(0.2*length1):] + X_at0[int(0.2*length0):])
    y_train = np.array(y_at1[int(0.2*length1):] + y_at0[int(0.2*length0):])
    X_test = np.array(X_at1[0:int(0.2*length1)] + X_at0[0:int(0.2*length0)])
    y_test = np.array(y_at1[0:int(0.2*length1)] + y_at0[0:int(0.2*length0)])
    return (X_train, y_train, X_test, y_test)

def do_pca(X_train, y_train, X_test, y_test):
    pca = PCA(n_components=2)
    pca.fit(X_train)
    var = pca.explained_variance_ratio_
    var_cum=np.cumsum(np.round(var, decimals=4)*100)
    X_train_trf= scale(pca.transform(X_train))
    X_test_trf = scale(pca.transform(X_test))
    return (X_train_trf, y_train, X_test_trf, y_test)

def minmax(X_2d):
    X0_min= X_2d[:,0].min()
    X0_max= X_2d[:,0].max()
    X1_min= X_2d[:,1].min()
    X1_max= X_2d[:,1].max()
    return (X0_min, X0_max, X1_min, X1_max)
##########################################################################################
if __name__== '__main__':
    (X_train, y_train, X_test, y_test)= opener()
    # print(X_train, y_train, X_test, y_test)
    X_2d, y, _, _= do_pca(X_train, y_train, X_test, y_test)
    print(X_2d)
    print(y)
    print(len(X_train), len(y_train), len(X_test), len(y_test))
    print(minmax(X_2d))
